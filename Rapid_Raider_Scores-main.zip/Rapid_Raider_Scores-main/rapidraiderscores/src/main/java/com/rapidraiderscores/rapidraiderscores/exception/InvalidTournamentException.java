package com.rapidraiderscores.rapidraiderscores.exception;

public class InvalidTournamentException extends Exception {

	public InvalidTournamentException(String string) {
		super(string);
	}

}
