package com.rapidraiderscores.rapidraiderscores.exception;

public class TeamAlreadyRegisteredException extends RuntimeException {

	public TeamAlreadyRegisteredException(String string) {
		super(string);
	}

}
