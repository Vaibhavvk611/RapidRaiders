package com.rapidraiderscores.rapidraiderscores.exception;

public class InvalidTeamException extends RuntimeException {

	public InvalidTeamException(String string) {
		super(string);
	}
	
}
