package com.rapidraiderscores.rapidraiderscores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RapidraiderscoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
